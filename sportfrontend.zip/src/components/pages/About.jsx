export default function About(){
    return(
        <>

        <>
  
  <main className="main">
    {/* Page Title */}
    <div className="page-title">
      <div className="heading">
        <div className="container">
          <div className="row d-flex justify-content-center text-center">
            <div className="col-lg-8">
              <h1 className="heading-title">About</h1>
              <p className="mb-0">
                Odio et unde deleniti. Deserunt numquam exercitationem. Officiis
                quo odio sint voluptas consequatur ut a odio voluptatem. Sit
                dolorum debitis veritatis natus dolores. Quasi ratione sint. Sit
                quaerat ipsum dolorem.
              </p>
            </div>
          </div>
        </div>
      </div>
      <nav className="breadcrumbs">
        <div className="container">
          <ol>
            <li>
              <a href="index.html">Home</a>
            </li>
            <li className="current">About</li>
          </ol>
        </div>
      </nav>
    </div>
    {/* End Page Title */}
    {/* About Section */}
    <section id="about" className="about section">
      <div className="container" data-aos="fade-up" data-aos-delay={100}>
        <div className="row align-items-center mb-5">
          <div className="col-lg-7">
            <div
              className="intro-content"
              data-aos="fade-right"
              data-aos-delay={200}
            >
              <div className="section-badge">
                <i className="bi bi-house-heart" />
                <span>Your Trusted Real Estate Partner</span>
              </div>
              <h2>Building Dreams, Creating Homes Since 2010</h2>
              <p className="lead-text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris.
                Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                accusantium doloremque laudantium.
              </p>
              <p>
                Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis
                et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim
                ipsam voluptatem quia voluptas sit aspernatur aut odit aut
                fugit.
              </p>
              <div
                className="founder-highlight"
                data-aos="fade-up"
                data-aos-delay={300}
              >
                <div className="founder-image">
                  <img
                    src="assets/img/person/person-m-7.webp"
                    alt="Founder"
                    className="img-fluid"
                  />
                </div>
                <div className="founder-info">
                  <blockquote>
                    "Neque porro quisquam est qui dolorem ipsum quia dolor sit
                    amet consectetur adipisci velit."
                  </blockquote>
                  <div className="founder-details">
                    <h5>Michael Thompson</h5>
                    <span>Founder &amp; CEO</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-5">
            <div
              className="visual-section"
              data-aos="fade-left"
              data-aos-delay={250}
            >
              <div className="main-image">
                <img
                  src="assets/img/real-estate/property-exterior-7.webp"
                  alt="Luxury Development"
                  className="img-fluid"
                />
                <div className="experience-badge">
                  <div className="badge-number">14+</div>
                  <div className="badge-text">Years of Excellence</div>
                </div>
              </div>
              <div className="overlay-image">
                <img
                  src="assets/img/real-estate/property-interior-6.webp"
                  alt="Interior Design"
                  className="img-fluid"
                />
              </div>
            </div>
          </div>
        </div>
        <div
          className="achievements-grid"
          data-aos="fade-up"
          data-aos-delay={350}
        >
          <div className="row text-center">
            <div className="col-lg-3 col-md-6 mb-4">
              <div
                className="achievement-item"
                data-aos="zoom-in"
                data-aos-delay={400}
              >
                <div className="achievement-icon">
                  <i className="bi bi-key" />
                </div>
                <div className="achievement-number">
                  <span
                    data-purecounter-start={0}
                    data-purecounter-end={2850}
                    data-purecounter-duration={2}
                    className="purecounter"
                  />
                  +
                </div>
                <div className="achievement-label">Properties Sold</div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 mb-4">
              <div
                className="achievement-item"
                data-aos="zoom-in"
                data-aos-delay={450}
              >
                <div className="achievement-icon">
                  <i className="bi bi-heart-fill" />
                </div>
                <div className="achievement-number">
                  <span
                    data-purecounter-start={0}
                    data-purecounter-end={98}
                    data-purecounter-duration={2}
                    className="purecounter"
                  />
                  %
                </div>
                <div className="achievement-label">Client Satisfaction</div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 mb-4">
              <div
                className="achievement-item"
                data-aos="zoom-in"
                data-aos-delay={500}
              >
                <div className="achievement-icon">
                  <i className="bi bi-geo-alt" />
                </div>
                <div className="achievement-number">
                  <span
                    data-purecounter-start={0}
                    data-purecounter-end={35}
                    data-purecounter-duration={2}
                    className="purecounter"
                  />
                </div>
                <div className="achievement-label">Cities Covered</div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 mb-4">
              <div
                className="achievement-item"
                data-aos="zoom-in"
                data-aos-delay={550}
              >
                <div className="achievement-icon">
                  <i className="bi bi-award" />
                </div>
                <div className="achievement-number">
                  <span
                    data-purecounter-start={0}
                    data-purecounter-end={127}
                    data-purecounter-duration={2}
                    className="purecounter"
                  />
                </div>
                <div className="achievement-label">Industry Awards</div>
              </div>
            </div>
          </div>
        </div>
        {/* End Achievements Grid */}
        <div
          className="timeline-section"
          data-aos="fade-up"
          data-aos-delay={400}
        >
          <div className="row justify-content-center">
            <div className="col-lg-10">
              <div className="section-header text-center mb-5">
                <h3>Our Journey of Excellence</h3>
                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium totam rem aperiam.
                </p>
              </div>
              <div className="timeline">
                <div
                  className="timeline-item"
                  data-aos="fade-right"
                  data-aos-delay={450}
                >
                  <div className="timeline-year">2010</div>
                  <div className="timeline-content">
                    <h4>Company Founded</h4>
                    <p>
                      Ut enim ad minim veniam, quis nostrud exercitation ullamco
                      laboris nisi ut aliquip ex ea commodo consequat.
                    </p>
                  </div>
                </div>
                <div
                  className="timeline-item"
                  data-aos="fade-left"
                  data-aos-delay={500}
                >
                  <div className="timeline-year">2015</div>
                  <div className="timeline-content">
                    <h4>1000th Property Milestone</h4>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                  </div>
                </div>
                <div
                  className="timeline-item"
                  data-aos="fade-right"
                  data-aos-delay={550}
                >
                  <div className="timeline-year">2020</div>
                  <div className="timeline-content">
                    <h4>Digital Innovation Launch</h4>
                    <p>
                      Excepteur sint occaecat cupidatat non proident, sunt in
                      culpa qui officia deserunt mollit anim id est laborum.
                    </p>
                  </div>
                </div>
                <div
                  className="timeline-item"
                  data-aos="fade-left"
                  data-aos-delay={600}
                >
                  <div className="timeline-year">2024</div>
                  <div className="timeline-content">
                    <h4>Regional Expansion</h4>
                    <p>
                      At vero eos et accusamus et iusto odio dignissimos ducimus
                      qui blanditiis praesentium voluptatum deleniti.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* End Timeline Section */}
        <div className="team-preview" data-aos="fade-up" data-aos-delay={450}>
          <div className="row justify-content-center">
            <div className="col-lg-8 text-center">
              <h3>Meet Our Expert Team</h3>
              <p className="team-description">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua quis
                nostrud exercitation.
              </p>
              <div className="team-grid">
                <div className="row justify-content-center">
                  <div className="col-lg-4 col-md-6 mb-4">
                    <div
                      className="team-member"
                      data-aos="flip-up"
                      data-aos-delay={500}
                    >
                      <div className="member-image">
                        <img
                          src="assets/img/real-estate/agent-5.webp"
                          alt="Team Member"
                          className="img-fluid"
                        />
                      </div>
                      <div className="member-info">
                        <h5>Sarah Martinez</h5>
                        <span>Senior Property Advisor</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-6 mb-4">
                    <div
                      className="team-member"
                      data-aos="flip-up"
                      data-aos-delay={550}
                    >
                      <div className="member-image">
                        <img
                          src="assets/img/real-estate/agent-2.webp"
                          alt="Team Member"
                          className="img-fluid"
                        />
                      </div>
                      <div className="member-info">
                        <h5>David Chen</h5>
                        <span>Investment Specialist</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <a href="team.html" className="view-team-btn">
                View Full Team
              </a>
            </div>
          </div>
        </div>
        {/* End Team Preview */}
      </div>
    </section>
    {/* /About Section */}
  </main>
  <footer id="footer" className="footer position-relative">
    <div className="container">
      <div className="row gy-5">
        <div className="col-lg-4">
          <div className="footer-content">
            <a
              href="index.html"
              className="logo d-flex align-items-center mb-4"
            >
              <span className="sitename">TheProperty</span>
            </a>
            <p className="mb-4">
              Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
              posuere cubilia curae. Donec velit neque auctor sit amet aliquam
              vel ullamcorper sit amet ligula.
            </p>
            <div className="newsletter-form">
              <h5>Stay Updated</h5>
              <form
                action="forms/newsletter.php"
                method="post"
                className="php-email-form"
              >
                <div className="input-group">
                  <input
                    type="email"
                    name="email"
                    className="form-control"
                    placeholder="Enter your email"
                    required=""
                  />
                  <button type="submit" className="btn-subscribe">
                    <i className="bi bi-send" />
                  </button>
                </div>
                <div className="loading">Loading</div>
                <div className="error-message" />
                <div className="sent-message">Thank you for subscribing!</div>
              </form>
            </div>
          </div>
        </div>
        <div className="col-lg-2 col-6">
          <div className="footer-links">
            <h4>Company</h4>
            <ul>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> About
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> Careers
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> Press
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> Blog
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> Contact
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="col-lg-2 col-6">
          <div className="footer-links">
            <h4>Solutions</h4>
            <ul>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> Digital Strategy
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> Cloud Computing
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> Data Analytics
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> AI Solutions
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-chevron-right" /> Cybersecurity
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="col-lg-4">
          <div className="footer-contact">
            <h4>Get in Touch</h4>
            <div className="contact-item">
              <div className="contact-icon">
                <i className="bi bi-geo-alt" />
              </div>
              <div className="contact-info">
                <p>
                  2847 Maple Avenue
                  <br />
                  Los Angeles, CA 90210
                  <br />
                  United States
                </p>
              </div>
            </div>
            <div className="contact-item">
              <div className="contact-icon">
                <i className="bi bi-telephone" />
              </div>
              <div className="contact-info">
                <p>+1 (555) 987-6543</p>
              </div>
            </div>
            <div className="contact-item">
              <div className="contact-icon">
                <i className="bi bi-envelope" />
              </div>
              <div className="contact-info">
                <p>contact@example.com</p>
              </div>
            </div>
            <div className="social-links">
              <a href="#">
                <i className="bi bi-facebook" />
              </a>
              <a href="#">
                <i className="bi bi-twitter-x" />
              </a>
              <a href="#">
                <i className="bi bi-linkedin" />
              </a>
              <a href="#">
                <i className="bi bi-youtube" />
              </a>
              <a href="#">
                <i className="bi bi-github" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="footer-bottom">
      <div className="container">
        <div className="row align-items-center">
          <div className="col-lg-6">
            <div className="copyright">
              <p>
                © <span>Copyright</span>{" "}
                <strong className="px-1 sitename">MyWebsite</strong>{" "}
                <span>All Rights Reserved</span>
              </p>
            </div>
          </div>
          <div className="col-lg-6">
            <div className="footer-bottom-links">
              <a href="#">Privacy Policy</a>
              <a href="#">Terms of Service</a>
              <a href="#">Cookie Policy</a>
            </div>
            <div className="credits">
              {/* All the links in the footer should remain intact. */}
              {/* You can delete the links only if you've purchased the pro version. */}
              {/* Licensing information: https://bootstrapmade.com/license/ */}
              {/* Purchase the pro version with working PHP/AJAX contact form: [buy-url] */}
              Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  {/* Scroll Top */}
  <a
    href="#"
    id="scroll-top"
    className="scroll-top d-flex align-items-center justify-content-center"
  >
    <i className="bi bi-arrow-up-short" />
  </a>
  {/* Preloader
  <div id="preloader" /> */}
  {/* Vendor JS Files */}
  {/* Main JS File */}
</>

        </>
    )
}